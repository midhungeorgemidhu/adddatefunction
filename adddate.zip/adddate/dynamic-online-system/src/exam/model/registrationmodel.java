package exam.model;

public class registrationmodel {

private String name;
private String gender;
private String email_id;
private String password;
private String mobile_no;
private int clss_no;
private String security_qn;
private String security_ans;
private int school_reg_no;
private String utype;
int attempt;



public int getAttempt() {
	return attempt;
}

public void setAttempt(int attempt) {
	this.attempt = attempt;
}

public registrationmodel(String name, String gender, String email_id, String password, String mobile_no,
		int clss_no, String security_qn, String security_ans, int school_reg_no, String utype, int attempt) {
	super();
	this.name = name;
	this.gender = gender;
	this.email_id = email_id;
	this.password = password;
	this.mobile_no = mobile_no;
	this.clss_no = clss_no;
	this.security_qn = security_qn;
	this.security_ans = security_ans;
	this.school_reg_no = school_reg_no;
	this.utype = utype;
	this.attempt=attempt;
}

public registrationmodel(String name, String gender, String email_id, String password, String mobile_no,
		int clss_no, String security_qn, String security_ans, int school_reg_no, String utype) {
	super();
	this.name = name;
	this.gender = gender;
	this.email_id = email_id;
	this.password = password;
	this.mobile_no = mobile_no;
	this.clss_no = clss_no;
	this.security_qn = security_qn;
	this.security_ans = security_ans;
	this.school_reg_no = school_reg_no;
	this.utype = utype;
}

public registrationmodel()
{
	
}



public registrationmodel(String email_id, String name, int clss_no, int school_reg_no, String mobile_no) {
	this.name = name;
	this.email_id = email_id;
	this.mobile_no = mobile_no;
	this.clss_no = clss_no;
	this.school_reg_no = school_reg_no;

}

public registrationmodel(String email_id, String name, int clss_no, int school_reg_no, String mobile_no,String security_qn, String security_ans, String password) {
	this.name = name;
	this.email_id = email_id;
	this.mobile_no = mobile_no;
	this.clss_no = clss_no;
	this.school_reg_no = school_reg_no;
	this.security_qn = security_qn;
	this.security_ans = security_ans;
	this.password = password;

}
public registrationmodel(String name,int clss_no,int school_reg_no,String mobile_no,String security_qn,String security_ans, String email_id)
{
	this.name = name;
	this.email_id = email_id;
	this.mobile_no = mobile_no;
	this.clss_no = clss_no;
	this.security_qn = security_qn;
	this.security_ans = security_ans;
	this.school_reg_no = school_reg_no;
}


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail_id() {
	return email_id;
}
public void setEmail_id(String email_id) {
	this.email_id = email_id;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getMobile_no() {
	return mobile_no;
}
public void setMobile_no(String mobile_no) {
	this.mobile_no = mobile_no;
}
public int getClss_no() {
	return clss_no;
}
public void setClss_no(int clss_no) {
	this.clss_no = clss_no;
}







public String getSecurity_qn() {
	return security_qn;
}





public void setSecurity_qn(String security_qn) {
	this.security_qn = security_qn;
}





public String getSecurity_ans() {
	return security_ans;
}





public void setSecurity_ans(String security_ans) {
	this.security_ans = security_ans;
}





public int getSchool_reg_no() {
	return school_reg_no;
}
public void setSchool_reg_no(int school_reg_no) {
	this.school_reg_no = school_reg_no;
}
public String getUtype() {
	return utype;
}
public void setUtype(String utype) {
	this.utype = utype;
}

}
