package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectQuestions;
import exam.DAO.selectStudents;
import exam.model.registrationmodel;

@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		ArrayList<registrationmodel> editstud= new ArrayList<registrationmodel>();
		String oper="";
		HttpSession adminsess1= request.getSession();
		
		String email_id=null;
		if(request.getParameter("oper")!=null )
		{
			oper=request.getParameter("oper");
			email_id=(String)request.getParameter("email_id");
			adminsess1.setAttribute("email_id", email_id);
			if(oper.equals("modify"))
			{
				editstud = selectStudents.getStudById(email_id);
				request.setAttribute("studlist", editstud);
				rd=request.getRequestDispatcher("editStudAdmin.jsp");		    
		 	    rd.forward(request, response);
			}
			else if(oper.equals("delete"))
			{
				if(selectStudents.deleteStudent(email_id) ==true)
				{
					rd=request.getRequestDispatcher("studentList");		    
			 	    rd.forward(request, response);
				}
			}
			
		}
		
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
