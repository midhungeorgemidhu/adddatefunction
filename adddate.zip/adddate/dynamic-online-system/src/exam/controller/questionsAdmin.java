package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectQuestions;
import exam.model.questionModel;

@WebServlet("/questionsAdmin")
public class questionsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession adminsess1=request.getSession();
		int clss_no=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		System.out.println(adminsess1.getAttribute("clss_no"));
		ArrayList<questionModel> quelist=new ArrayList<questionModel>();
		ArrayList<questionModel> subname=new ArrayList<questionModel>();
		String sub_name=request.getParameter("select");
			if(sub_name!=null)
		{
			quelist=selectQuestions.getQuestionForStud(sub_name, clss_no);
			request.setAttribute("questions", quelist);
			subname=(ArrayList<questionModel>) selectQuestions.getSubjectName(clss_no);
			request.setAttribute("subname", subname);
			rd=request.getRequestDispatcher("questionsAdmin.jsp");
			rd.forward(request, response);
		}else
		if(selectQuestions.getSubjectName(clss_no)!=null)
			{
			subname=(ArrayList<questionModel>) selectQuestions.getSubjectName(clss_no);
			request.setAttribute("subname", subname);
			rd=request.getRequestDispatcher("questionsAdmin.jsp");
			rd.forward(request, response);
			}
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
