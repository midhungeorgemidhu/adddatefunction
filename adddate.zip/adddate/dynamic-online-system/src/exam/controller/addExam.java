package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.model.examModel;

@WebServlet("/addExam")
public class addExam extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		Boolean flag=false;
		Boolean flag1=true;
		Boolean flag2=false;
		PrintWriter out=response.getWriter();
		int exam_id=Integer.valueOf((String) request.getParameter("exam_id"));
		String sub_name=(String) request.getParameter("sub_name");
		int clss_no=Integer.valueOf((String) request.getParameter("clss_no"));
		int no_of_que=Integer.valueOf((String) request.getParameter("no_of_ques"));
		String time_interval=(String) request.getParameter("time_interval");
		int total_marks=Integer.valueOf((String) request.getParameter("total_marks"));;
		String start_date=(String) request.getParameter("startdate");
		String end_date=(String) request.getParameter("enddate");
		String exam_date= (String) request.getParameter("examdate");
		System.out.print(exam_date);
		String startdate=null;
		String enddate=null;
		Date today=new Date(2020-10-9);
		int n=0,n1=0;
		HttpSession adminsess1=request.getSession();
		int clssno1=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		ArrayList<examModel> examdate= new ArrayList<examModel>();
		ArrayList<examModel> examinter= new ArrayList<examModel>();
		ArrayList<String> examsub= new ArrayList<String>();
		examdate=selectExam.getExamDate(clssno1);
		examinter=selectExam.getExamInterval(clssno1);
		examsub=selectExam.getExamSubject(clssno1);
		n=exam_date.compareTo(start_date);
		n1=exam_date.compareTo(end_date);
		for(examModel r:examdate)
		{
			if(r.getExam_date().equals(exam_date))
			{
				flag=true;
				break;
			}
		}
		for(examModel r:examinter)
		{
			startdate=r.getStart_date();
			enddate=r.getEnd_date();
			if(startdate.equals(start_date) || enddate.equals(end_date))
			{
				flag1=false;
				break;
			}
		}
		for(String r: examsub)
		{
			if(r.equals(sub_name))
			{
				flag2=true;
				break;
			}
		}
		System.out.println(exam_date+","+start_date+","+end_date);
		examModel e=new examModel(exam_id, sub_name, clss_no, no_of_que,time_interval,total_marks,start_date, end_date,exam_date);
		if(flag.equals(true))
		{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Already exam scheduled on that date, please select anyother within week');");
			out.println("location='addExamAdmin.jsp';");
			out.println("</script>");
		}else if(flag1.equals(true))
		{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Make sure the start date and end date is not altered');");
			out.println("location='addExamAdmin.jsp';");
			out.println("</script>");
		}else if(flag2.equals(true))
		{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Already exam is scheduled for this subject');");
			out.println("location='addExamAdmin.jsp';");
			out.println("</script>");
		}else{
			
	
		if(selectExam.addExam(e) ==true)
		{
			rd=request.getRequestDispatcher("examList");
			rd.forward(request, response);
		}else{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Couldn't insert!!, check credentials');");
			out.println("location='addExamAdmin.jsp';");
			out.println("</script>");
		}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
