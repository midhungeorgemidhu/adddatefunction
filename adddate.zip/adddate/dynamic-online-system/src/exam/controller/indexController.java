package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import exam.DAO.indexDAO;
import exam.DAO.mainExamDAO;
import exam.model.examModel;
import exam.model.registrationmodel;

@WebServlet("/indexController")
public class indexController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession session1=request.getSession();
		HttpSession session3=request.getSession();
		HttpSession session4=request.getSession();
		ArrayList<registrationmodel> student;
		String email_id=(String) session1.getAttribute("email_id");
		if(indexDAO.getStudentDetail(email_id)!=null)
		{
			student=indexDAO.getStudentDetail(email_id);
			for(registrationmodel r: student)
			{
				ArrayList<examModel> detail;
				if(mainExamDAO.getExamDetail(r.getClss_no())!=null)
				{
					detail=mainExamDAO.getExamDetail(r.getClss_no());
					for(examModel d: detail){
						if(session3.getAttribute("clss_no")==null)
							  session3.setAttribute("clss_no",d.getClss_no());
						session4.setAttribute("sub_name", d.getSub_name());
					}
				}
				session4.setAttribute("clss_no", r.getClss_no());
					 
			}
			
			request.setAttribute("student", student);
			rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
		else
		{
			rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
