package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.model.examModel;

@WebServlet("/examList")
public class examList extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		PrintWriter out= response.getWriter();
		HttpSession adminsess1=request.getSession();
		ArrayList<examModel> exams= new ArrayList<examModel>();
		int clss_no= Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		if(selectExam.getExamByClass(clss_no)!=null)
		{
			exams=selectExam.getExamByClass(clss_no);
			request.setAttribute("exams", exams);
			rd=request.getRequestDispatcher("examListAdmin.jsp");
			rd.forward(request, response);
		}else{
			request.setAttribute("errormsg", "Sorry no exams found for class, click on add exam to add exam");
			rd=request.getRequestDispatcher("examListAdmin.jsp");
			rd.forward(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
