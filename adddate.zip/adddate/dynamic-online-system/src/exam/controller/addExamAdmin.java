package exam.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.DAO.selectQuestions;
import exam.model.examModel;
import exam.model.questionModel;

@WebServlet("/addExamAdmin")
public class addExamAdmin extends HttpServlet {
	
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String startdate=null;
		String enddate=null;
		String examdate=null;
		Date exam=null;
		HttpSession adminsess1=request.getSession();
		HttpSession adminsess2=request.getSession();
		HttpSession adminsess3=request.getSession();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		int clssno1=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		System.out.print(clssno1);
		ArrayList<examModel> examinter= new ArrayList<examModel>();
		examinter=selectExam.getExamInterval(clssno1);
		for(examModel r:examinter)
		{
			startdate=r.getStart_date();
			enddate=r.getEnd_date();
			exam=selectExam.getExamDate1(clssno1);
				int d=exam.getDate(), m=exam.getMonth(), y=exam.getYear(), nd=00, nm=00, ny=0000;
				if (m%2!=0 && m<=07)
				{
                if (d==31)
                {
                	nd=01;
                	nm=m+1;
                	ny=y;
                	} 
                } else if (m%2==0 && 8<=m && m<=12) 
                { 
                	if (d==31)
                	{ 
                		nd=1;
                		nm=m+1; 
                		ny=y;
                		} 
                	} 
                else if (m%2==0 && 4<=m && m<=6)
                { 
                
                	if (d==30)
                	{ 
                		nd=1;
                		nm=m=1; 
                		ny=y;
                		} 
                	} 
                else if (m%2!=0 && 9<=m && m<=11)
                {
                	if (d==30)
                	{
                		nd=1;
                		nm=m+1;
                		ny=y;
                		} 
                	}
                else if (m==2 && y%4==0)
                {
                	if (d==29) 
                	{ 
                		nd=1;
                		nm=m+1; 
                		ny=y;
                		} 
                	}
                else if (m==2 && y%4!=0)
                { 
                	if (d==28) 
                	{ 
                		nd=1;
                		nm=m+1; 
                		ny=y;
                		} 
                	} 
                else if (m==12 && d==31)
                { 
                	nd=1;
                	nm=1; 
                	ny=y+1; 
                	} 
                else 
                { 
                	nd=d+1;
                	nm=m;
                	ny=y;
                	}
				
			examdate= sdf.format(new Date(ny,nm,nd));
			adminsess3.setAttribute("examdate", examdate);
			System.out.println(r.getStart_date());
			System.out.println(r.getEnd_date());
			adminsess2.setAttribute("startdate", startdate);
			adminsess2.setAttribute("enddate", enddate);
			break;
		}
		ArrayList<Integer> quest= new ArrayList<Integer>();
		quest=selectExam.getExamId(clssno1);
		int n=1;
		Boolean flag=false;
		for(Integer r: quest)
		{
			if(r== n)
			{
				flag=false;
				n++;
				continue;
			}else{
				flag=true;
				adminsess1.setAttribute("examid", n);
				System.out.println(r);
				System.out.println(n);
				break;
			}
		}
		
		rd=request.getRequestDispatcher("addExamAdmin.jsp");
		rd.forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
