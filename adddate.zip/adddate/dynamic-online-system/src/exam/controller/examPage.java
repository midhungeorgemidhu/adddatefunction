package exam.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.examPageDAO;
import exam.model.*;

@WebServlet("/examPage")
public class examPage extends HttpServlet {
	String pattern ="yyyy-MM-dd";
	SimpleDateFormat simpleDate=new SimpleDateFormat(pattern);
	String date=simpleDate.format(new Date());
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	RequestDispatcher rd;
	HttpSession session3= request.getSession();
	HttpSession session1= request.getSession();
	String email_id1= (String)session1.getAttribute("email_id");
	int clss_no= (int) session3.getAttribute("clss_no");
	ArrayList<examModel> exam;
	int examid1=examPageDAO.getexamid(email_id1);
	request.setAttribute("examid", email_id1);
	if(examPageDAO.getExamDetail(clss_no)!=null )
	{
		exam=examPageDAO.getExamDetail(clss_no);
		request.setAttribute("exam", exam);
		for(examModel r: exam)
		{
			if(r.getExam_date().equals(date))
			{
				
				session3.setAttribute("sub_name", r.getSub_name());
				session3.setAttribute("exam_id", r.getExam_id());
				if(examid1==r.getExam_id()){
					System.out.println("performing");
					System.out.println(examid1);
						request.setAttribute("succmsg11", "You have succesfully completed today's exam!!!");
				}
			}
		}
		
		rd=request.getRequestDispatcher("examPage.jsp");
		rd.forward(request, response);
	}
	else
	{
		rd=request.getRequestDispatcher("indexController");
		rd.forward(request, response);
	}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
