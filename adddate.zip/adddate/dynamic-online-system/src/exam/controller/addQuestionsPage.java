package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exam.DAO.selectQuestions;
import exam.model.questionModel;

@WebServlet("/addQuestionsPage")
public class addQuestionsPage extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		PrintWriter out= response.getWriter();
		Boolean flag=false;
		int q_id=Integer.valueOf((String) request.getParameter("q_id").trim());
		String question=request.getParameter("que");
		String op1=request.getParameter("op1");
		String op2=request.getParameter("op2");
		String op3=request.getParameter("op3");
		String op4=request.getParameter("op4");
		String ans=request.getParameter("ans");
		int clss_no=Integer.valueOf((String)request.getParameter("clss_no").trim());
		String sub_name=(String) request.getParameter("sub");
		if(request.getParameter("submit")!=null){
		questionModel q=new questionModel( q_id, clss_no, question, op1, op2, op3, op4, ans, sub_name);
		if( selectQuestions.addQuest(q)==true)
		{
			flag=true;
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Succesfully Updated!');");
			out.println("location='addQuest';");
			out.println("</script>");
		}
		else
		{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Couldn't insert!, Please Check All fields');");
			out.println("location='addQuest';");
			out.println("</script>");
		}
		}else if(request.getParameter("back")!=null)
		{
			System.out.println("hi");
			rd=request.getRequestDispatcher("questionsAdmin");
			rd.forward(request, response);
		}else if(request.getParameter("next")!=null && flag.equals(true) )
		{
			rd=request.getRequestDispatcher("addQuest");
			rd.forward(request, response);
		}else if(request.getParameter("next")!=null)
		{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Please submit the question inserted before proceeding to next question!!!');");
			out.println("location='addQuest';");
			out.println("</script>");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
