package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import exam.model.*;

public class registerDAO {
	private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	
		  String JdbcURL = "jdbc:mysql://localhost:3306/examDB?" + "autoReconnect=true&useSSL=false";
	      String Username = "root";
	      String password = "";
	       con = null;      
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	 // con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/test1","root","");  
	         con = DriverManager.getConnection(JdbcURL, Username, password);
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	  public static Boolean createacc(registrationmodel r)
	  {  
		  try
		  {
		  getConnection();
		  int nor=0;
	      stmt=con.prepareStatement("insert into registration values(?,?,?,?,?,?,?,?,?,?) "); 
	      stmt.setString(1, r.getName());
	      stmt.setString(2, r.getGender());
	      stmt.setString(3, r.getEmail_id());
	      stmt.setString(4, r.getPassword());
	      stmt.setString(5, r.getMobile_no());
	      stmt.setInt(6, r.getClss_no());
	      stmt.setString(7, r.getSecurity_qn());
	      stmt.setString(8, r.getSecurity_ans());
	      stmt.setInt(9, r.getSchool_reg_no());
	      stmt.setString(10, r.getUtype());
	      nor=stmt.executeUpdate();
		     closeConnection();	 
		    if(nor>0)
		    {
		    	return true;
		    }
		    return false;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }  	  
	  }
}
