package exam.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.examModel;
import exam.model.questionModel;

public class selectExam {
	private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<examModel> getExamByClass( int clss_no)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select exam_id, sub_name, clss_no, no_of_que, time_interval, total_marks,  start_date, end_date, exam_date from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getInt(1),rs.getString(2),rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getInt(6),rs.getString(7), rs.getString(8), rs.getString(9));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<examModel> getExamInterval( int clss_no)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  start_date, end_date from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getString(1),rs.getString(2));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static Date getExamDate1( int clss_no)
	  {
		  Date exam=null; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select max(exam_date) from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  exam=rs.getDate(1);	
			 
			  }  
		     closeConnection();	 
		     return exam;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	 
	  public static ArrayList<examModel> getExamDate( int clss_no)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  exam_date from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getString(1));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<String> getExamSubject( int clss_no)
	  {
		  ArrayList <String> examlist=new ArrayList<String>();
		  String temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  sub_name from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=rs.getString(1);	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<examModel> getExamInterval1( int clss_no, int exam_id)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  start_date, end_date from exam where clss_no=? and NOT exam_id=?"); 
	      stmt.setInt(1, clss_no);
	      stmt.setInt(2, exam_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getString(1),rs.getString(2));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<examModel> getExamDate1( int clss_no, int exam_id)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  exam_date from exam where clss_no=? and NOT exam_id=? "); 
	      stmt.setInt(1, clss_no);
	      stmt.setInt(2, exam_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getString(1));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<String> getExamSubject1( int clss_no, int exam_id)
	  {
		  ArrayList <String> examlist=new ArrayList<String>();
		  String temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  sub_name from exam where clss_no=? and NOT exam_id=? "); 
	      stmt.setInt(1, clss_no);
	      stmt.setInt(2, exam_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=rs.getString(1);	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<Integer> getExamId( int clss_no)
	  {
		  ArrayList <Integer> examlist=new ArrayList<Integer>();
		  int temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select  exam_id from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		  while(rs.next())
			  
			  {  		   
			  temp=rs.getInt(1);	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  
	  public static ArrayList<examModel> getExamById( int exam_id)
	  {
		  ArrayList <examModel> examlist=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select exam_id, sub_name, clss_no, no_of_que, time_interval, total_marks,  start_date, end_date, exam_date from exam where exam_id=? "); 
	      stmt.setInt(1, exam_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  
			  {  		   
			  temp=new examModel(rs.getInt(1),rs.getString(2),rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getInt(6),rs.getString(7), rs.getString(8), rs.getString(9));	
			  examlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return examlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	 
	  
	 
	 
	  public static Boolean updateExamById(examModel q, int exam_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("update exam set exam_id=?, sub_name=?, clss_no=?, no_of_que=?, time_interval=?, total_marks=?,  start_date=?, end_date=?, exam_date=? where exam_id=? "); 
	      stmt.setInt(1, q.getExam_id());
	      stmt.setString(2, q.getSub_name());
	      stmt.setInt(3, q.getClss_no());
	      stmt.setInt(4, q.getNo_of_que());
	      stmt.setString(5, q.getTime_interval());
	      stmt.setInt(6, q.getTotal_marks());
	      stmt.setString(7, q.getStart_date());
	      stmt.setString(8, q.getEnd_date());
	      stmt.setString(9, q.getExam_date());
	      stmt.setInt(10, exam_id);
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  public static Boolean addExam(examModel q)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("insert into exam values (?,?,?,?,?,?,?,?,?) "); 
	      stmt.setInt(1, q.getExam_id());
	      stmt.setString(2, q.getSub_name());
	      stmt.setInt(3, q.getClss_no());
	      stmt.setInt(5, q.getNo_of_que());
	      stmt.setString(6, q.getTime_interval());
	      stmt.setInt(7, q.getTotal_marks());
	      stmt.setString(8, q.getStart_date());
	      stmt.setString(9, q.getEnd_date());
	      stmt.setString(4, q.getExam_date());
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  public static Boolean deleteExamById( int exam_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("delete from exam where exam_id=? "); 
	      stmt.setInt(1, exam_id);
	     
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
}
